#--------------------------------------------------------------------
# MlengelaDP9
# Programmer: Daudi Mlengela
# Email: dmlengela@cnm.edu
# Purpose: Demostrate how to define a class with a file input
#---------------------------------------------------------------------

from geopoint import GeoPoint
import sys
#--------------------------------------------------------------------
# Writing Points.txt file
#--------------------------------------------------------------------

#f = open('Points.txt', 'w')
#f. write('35.0714,-106.6289,Main Campus\n')
#f. write('35.0998,-104.0639,Montoya\n')
#f. write('35.2328,-106.6630,Rio Rancho\n')
#f. write('35.1836,-106.5939,ATC\n')
#f.close()

#-------------------------------------------------------------------
# Reading Points.txt file
#-------------------------------------------------------------------

#f = open('Points.txt')
#while True:
   #line = f.readline()
   #if not line: break
   #print(line)
#f.close()

#---------------------------------------------------------------------
# getDescription
#---------------------------------------------------------------------

def getDescription(prompt):
    description = input("Enter a description for your location: ").strip()

    if description == "":
        raise Exception("Description cannot be empty")

#--------------------------------------------------------------------------
# script Begins here
#--------------------------------------------------------------------------
pointsList = []
fileName = "Points.txt"

try:
    with open(fileName) as file:
        for line in file:
            values = line.split(",")

            latitude     = float(values[0].strip())
            longitude    = float(values[1].strip())
            description  = values[2].strip()

            pointsList.append(GeoPoint(latitude, longitude, description))

except:

    print("Could not open input file: [" + fileName + "]")
    sys.exit()

keepGoing = True

while keepGoing:

    try:
        description = getDescription("Enter  description for your location: ")
        lat         = float(input("Enter latitude value in decimal degrees: "))
        lon         = float(input("Enter longitude value in decimal degrees: "))

        thePoint    = GeoPoint(lat, lon, description)
        minDistance = 0
        minEntry    = None

        for entry in pointsList:
            distance = entry.CalcDistance(thePoint)
            if minDistance == 0 or distance < minDistance:
               minDistance = distance
               minEntry    = entry

        print("You are closest to {0}, which is located at ({1})".format(
            minEntry.description, minEntry.point))
    except ValueError:
        print("Wrong type of input!")
    except ValueError as e:
            print("ValueError occurred! ({0})".format(e))
    except Exception as e:
            print("Something went wrong: ({0})".format(e))
    answer = input("Would you like to do another? ").strip().lower()

    if answer == "" or answer[0] != 'y':
            keepGoing = False

    print("Good bye, thank for using the Geo Points program!")
